# Fight-Game

Fighting Game made with HTML, CSS and JS

<img src=img/Screenshot.png></img>

Direct Link: https://fighting-game-mauromarchesan.netlify.app/

Controls:

Player one: A,W,D and spacebar to attack;

Player two: Arrows (up, right, left) and down Arrow to attack;

Thanks to @https://github.com/WannyMartins who helped me with animation!
